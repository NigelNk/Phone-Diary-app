package contactdiary;

import javax.swing.JOptionPane;

public class MyThread implements Runnable {

    @Override
    public void run() {
        try {
            MainWin.msglb.show();
            Thread.sleep(1500);
            MainWin.msglb.hide();
        } catch (InterruptedException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
