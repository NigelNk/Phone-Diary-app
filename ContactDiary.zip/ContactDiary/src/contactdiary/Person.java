package contactdiary;

import java.io.Serializable;

public class Person implements Serializable {

    private String name;
    private long phoneNumber;
    private String dateOfBirth;
    private String bornDay;

    public Person(String name, long phoneNumber, String dateOfBirth, String bornDay) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.dateOfBirth = dateOfBirth;
        this.bornDay = bornDay;
    }

    public String getName() {
        return name;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getBornDay() {
        return bornDay;
    }

}
