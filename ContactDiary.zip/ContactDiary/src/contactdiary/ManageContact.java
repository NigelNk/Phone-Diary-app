package contactdiary;

import static contactdiary.AddContact.contact;
import java.awt.HeadlessException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class ManageContact extends javax.swing.JDialog {

    /**
     * Creates new form ManageContact
     *
     * @param parent
     * @param modal
     */
    private final ImageIcon icon;

    public ManageContact(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        icon = new ImageIcon(getClass().getResource("/contactdiary/edit-32x32-1214336.png"));
        setIconImage(icon.getImage());

        readData();
        try {
            jComboBox.setSelectedIndex(0);
        } catch (IllegalArgumentException il) {
            JOptionPane.showMessageDialog(null, "Hey, Contact list is empty!");
            jTextField1.setEditable(false);
            jTextField2.setEditable(false);
        }
    }

    void updateDataToFile() {
        try {
            FileOutputStream file = new FileOutputStream("myContacts.dat");
            try (ObjectOutputStream writer = new ObjectOutputStream(file)) {
                for (int i = 0; i < contact.size(); i++) {
                    writer.writeObject(contact.get(i));
                }
            }
            readData();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    private void readData() {
        String[] personArray = new String[contact.size()];
        for (int i = 0; i < personArray.length; i++) {
            personArray[i] = contact.get(i).getName();
        }
        jComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(personArray));
    }

    private void showData() {
        try {
            int index = jComboBox.getSelectedIndex();
            String getDate = contact.get(index).getDateOfBirth();
            Date date = new Date(getDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);

            jTextField1.setText(contact.get(index).getName());
            jTextField2.setText("0" + contact.get(index).getPhoneNumber());
            jSpinner1.setValue(cal.get(Calendar.DATE));
            jSpinner3.setValue(cal.get(Calendar.YEAR));
            // adding 1 to month for normal human readable form
            jSpinner2.setValue(((int) cal.get(Calendar.MONTH) + 1));
        } catch (IndexOutOfBoundsException ib) {
            JOptionPane.showMessageDialog(null, "No data to show");
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel7 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jLabel8 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Manage contact");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Edit Contact");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 52));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Select a name:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 81, -1, -1));

        jComboBox.setBackground(new java.awt.Color(153, 153, 153));
        jComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 113, 214, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("EDIT:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Name:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 177, -1, -1));

        jTextField1.setBackground(new java.awt.Color(153, 153, 153));
        jTextField1.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 255, 255));
        jTextField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 203, 177, 28));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Phone number:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 243, -1, 22));

        jTextField2.setBackground(new java.awt.Color(153, 153, 153));
        jTextField2.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(255, 255, 255));
        jTextField2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 270, 180, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel6.setText("Date:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 310, -1, -1));

        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));
        jSpinner1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(jSpinner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 313, 78, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel7.setText("Month:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 339, -1, -1));

        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(1, 1, 12, 1));
        jSpinner2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 342, 78, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel8.setText("Year:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(112, 368, -1, -1));

        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(2004, 1964, 2098, 1));
        jSpinner3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 371, 78, -1));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/contactdiary/save-24x24-1784384.png"))); // NOI18N
        jButton1.setText("save");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 410, -1, -1));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/contactdiary/trash-24x24-1214283.png"))); // NOI18N
        jButton2.setText("Delete");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxActionPerformed
        showData();
    }//GEN-LAST:event_jComboBoxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String name = jTextField1.getText();
        String n = jTextField2.getText();
        int date = (int) jSpinner1.getValue();
        int month = (int) jSpinner2.getValue();
        int year = (int) jSpinner3.getValue();

        if (name.isEmpty() || n.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter all fields!");

        } else if (date == 0 || month == 0 || year == 0) {
            JOptionPane.showMessageDialog(null, "Please enter correct date,month or year!");
        } else if (date >= 32 || date <= 0 || month >= 13 || month <= 0) {
            JOptionPane.showMessageDialog(null, "Date or month is out o range!");
        } else {
            try {
                long num = Long.parseLong(n);
                Calendar cal = Calendar.getInstance();

                if (month == 1) {
                    cal.set(year, 0, date, 0, 0, 0);
                } else {
                    cal.set(year, month - 1, date, 0, 0, 0);
                }
                int bornDay = cal.get(Calendar.DAY_OF_WEEK);
                String bDay;
                switch (bornDay) {
                    case 1 ->
                        bDay = "Sunday";
                    case 2 ->
                        bDay = "Monday";
                    case 3 ->
                        bDay = "Tuesday";
                    case 4 ->
                        bDay = "Wednesday";
                    case 5 ->
                        bDay = "Thursday";
                    case 6 ->
                        bDay = "Friday";
                    default ->
                        bDay = "Saturday";
                }

                int index = jComboBox.getSelectedIndex();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM YYYY");
                String formatedDate = dateFormat.format(cal.getTime());
                String birthday = "" + formatedDate;

                Person person = new Person(name, num, birthday, bDay);
                // remove the element first then update it on the same index with an updated version of it
                contact.remove(index);
                contact.add(index, person);
                updateDataToFile();
                JOptionPane.showMessageDialog(null, "Contact successfully updated!");
                showData();
                new AddContact(new javax.swing.JFrame(), true).readData();

            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            } catch (NumberFormatException nf) {
                JOptionPane.showMessageDialog(null, "Please provide a correct phone number!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int selectedIndex = jComboBox.getSelectedIndex();
        int que = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove: " + contact.get(selectedIndex).getName() + " ?", "Deleting a contact", JOptionPane.YES_NO_OPTION);
        if (que == 0) {
            contact.remove(selectedIndex);
            updateDataToFile();
            JOptionPane.showMessageDialog(null, "Successfully deleted a contact!");
            showData();
            new AddContact(new javax.swing.JFrame(), true).readData();

        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageContact.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageContact.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageContact.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageContact.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(() -> {
            ManageContact dialog = new ManageContact(new javax.swing.JFrame(), true);
            dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    System.exit(0);
                }
            });
            dialog.setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private static javax.swing.JComboBox<String> jComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private static javax.swing.JSpinner jSpinner1;
    private static javax.swing.JSpinner jSpinner2;
    private static javax.swing.JSpinner jSpinner3;
    private static javax.swing.JTextField jTextField1;
    private static javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
